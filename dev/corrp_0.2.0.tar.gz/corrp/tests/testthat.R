library(testthat)
library(corrp)

test_check("corrp")


